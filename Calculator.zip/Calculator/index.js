"use strict";
let show = document.querySelector(".menu1");

document.querySelector(".fa-bars").addEventListener("click", () => {
  if (show.classList.contains("hidden")) {
    show.classList.remove("hidden");
  } else {
    show.classList.add("hidden");
  }
});

let count = 0;
let main_branch = document.querySelector("#main");
let alpha = "";
let ftn = (alp) => {
  if (count != 0) {
    alpha = "";
    count = 0;
  }
  alpha += alp;
  main_branch.innerText = alpha;
};
let ftn1 = (alp) => {
  count = 0;
  alpha += alp;
  main_branch.innerText = alpha;
};
let del = () => {
  if (alpha == "" || alpha == "0") {
    return;
  }
  alpha = alpha.slice(0, -1);
  main_branch.innerText = alpha;
};
let ac = () => {
  alpha = "";
  main_branch.innerText = "0";
};
let calc = () => {
  let alph = alpha;
  for (let i = 0; i < alph.length; i++) {
    let k = Number(alph.slice(0, i));
    let k1 = Number(alph.slice(i + 1));
    let confirm = "";
    if (alph[i] == "+" || alph[i] == "-" || alph[i] == "*" || alph[i] == "/") {
      let final = 0;
      if (alph[i] == "+") {
        final = k + k1;
      } else if (alph[i] == "*") {
        final = k * k1;
      } else if (alph[i] == "-") {
        final = k - k1;
      } else {
        final = k / k1;
        alpha = final;
        main_branch.innerText = alpha;
        return;
      }
      alpha = final;
      let result = 0;
      let gamma = String(alpha);
      for (let i = 0; i < gamma.length; i++) {
        if (result % 3 == 0 && result != 0) {
          confirm += ",";
        }
        // console.log(gamma[0]);
        confirm += gamma[i];
        result++;
        // console.log(confirm);
      }
      //   console.log(confirm);
      main_branch.innerText = confirm;
      count++;
      return;
    }
  }
};