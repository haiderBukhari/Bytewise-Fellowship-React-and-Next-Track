import React, { useState } from 'react'
import "./Setinput.css"
const Setinput = ({list, setlist}) => {
    let [f_name, setf_name] = useState("")
    let [l_name, setl_name] = useState("")
    let [age, setage] = useState(0)
    let [email, setemail] = useState("")
    let handlesubmit = (e) =>{
        e.preventDefault();
        console.log(e);
        console.log(f_name);
        let new_list = {
            name: `${f_name} ${l_name}`,
            ages: age,
            emails: email
        }
        setlist([...list, new_list])
    }
    return (
    <section>
        <div className='input'>
            <div className='input-field'>
                <form onSubmit={handlesubmit} action="">
                <input onChange={(e)=>setf_name(e.target.value)} className= "text-field" type="text" placeholder='First Name' autoComplete='off' />
                <input  onChange={(e)=>setl_name(e.target.value)} type="text" placeholder='Last Name' autoComplete='off'/>
                <input onChange={(e)=>setage(e.target.value)}  type="number" name="" id="" placeholder='age' autoComplete='off'/>
                <input onChange={(e)=>setemail(e.target.value)} type="email" name="" id="" placeholder='Email'/>
                <button type='submit'>Submit</button>
                </form>
            </div>
            <div>
               
            </div>
        </div>
    </section>
  )
}

export default Setinput