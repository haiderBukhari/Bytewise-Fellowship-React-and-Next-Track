import React from "react";
import "./Information.css";
const Information = ({list, setlist }) => {
  console.log(list);
  return (
    <>
      <div className="detail">
        {list.map((arr) => (
          <div className="sub_detail">
            <p>
              Name: <span>{arr.name}</span>
            </p>
            <p>
              Age: <span>{arr.ages}</span>
            </p>
            <p id="email">
              Email: <span>{arr.emails}</span>
            </p>
          </div>
        ))}
      </div>
    </>
  );
};

export default Information;
