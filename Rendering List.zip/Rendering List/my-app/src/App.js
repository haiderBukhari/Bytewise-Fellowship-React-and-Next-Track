import React, { useState } from 'react'
import "./App.css";
import Information from "./components/Information"
import Setinput from './components/Setinput';
const App = () => {
  let [lists, setlist] = useState([]);
  return (
    <div className='main'>
      <div className='sub-main'>
        <Setinput list={lists} setlist={setlist}/>
        <Information list={lists} setlist={setlist}/>
      </div>
    </div>
  )
}

export default App